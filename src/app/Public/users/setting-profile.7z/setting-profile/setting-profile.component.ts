import { Component, OnInit } from '@angular/core';
import { Form } from '@angular/forms';
import { UserConfigService } from 'src/app/Services/user-config.service';
import { user } from 'src/app/_model/user';

@Component({
  selector: 'app-setting-profile',
  templateUrl: './setting-profile.component.html',
  styleUrls: ['./setting-profile.component.css']
})
export class SettingProfileComponent implements OnInit {

  userGet: any;

  constructor(private userset:UserConfigService) { }

  ngOnInit(): void {
    this.userset.getUser().subscribe((res: user)=>{
      this.userGet = res;
   });
  }

  changeUserData(form: any){

  }

  changePassword(form: Form): void {

  }

}
